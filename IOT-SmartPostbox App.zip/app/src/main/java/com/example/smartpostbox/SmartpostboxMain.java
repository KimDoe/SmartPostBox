package com.example.smartpostbox;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.p2p.WifiP2pManager;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;


public class SmartpostboxMain extends AppCompatActivity {

    Switch switchAnzeigeSma;
    Button btnLogout, btnDatenHolenSmart;
    ImageView imgVollSma, imgLeerSma;
    TextView TVAnzeigeSma, TVSmart;
    CheckBox CBAnzeigeAktivierenSma;
    FloatingActionButton btnPlusSma;

    public int a = 0;
    final String url_particle = "console.particle.io/devices/e00fce68b3c08327b9815931";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_smartpostbox_main);

        btnLogout = (Button) findViewById(R.id.btnLogout);
        btnPlusSma = (FloatingActionButton) findViewById(R.id.btnPlusSma);
        btnDatenHolenSmart = (Button) findViewById(R.id.btnDatenHolenSmart);

        imgLeerSma = (ImageView) findViewById(R.id.imgLeer_);
        imgVollSma = (ImageView) findViewById(R.id.imgVoll_);

        switchAnzeigeSma = (Switch) findViewById(R.id.switchAnzeigeSma);

        TVAnzeigeSma = (TextView) findViewById(R.id.TVAnzeigeSma);
        TVSmart = (TextView) findViewById(R.id.TVSmart);

        CBAnzeigeAktivierenSma = (CheckBox) findViewById(R.id.CBAnzeigeAktivierenSma);

        imgLeerSma.setVisibility(View.VISIBLE);
        imgVollSma.setVisibility(View.INVISIBLE);

        //Zurück Button -> Main
        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMain();
            }
        });


       // postboxAnzeige();

        //Button Plus -> Registrierung
        btnPlusSma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openRegistrierung();
            }
        });

        btnDatenHolenSmart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (internetAvailable()){
                    sendToServer();
                    System.out.println("Taste gedrückt Daten werden geholt");
                }else{
                    //Toast.makeText(this, "Internet ist nicht verfügbar", Toast.LENGTH_SHORT).show();
                    System.out.println("Etwas ist schief gelaufen");
                }
            }
        });
    }

    //Zurück zur Startseite -> über einen Button
    public void openMain () {
        Intent Main = new Intent(this, MainActivity.class);
        startActivity(Main);
    }

    //Zurück zu Registrierung -> über einen Button
    public void openRegistrierung () {
        Intent Reg = new Intent(this, Registrierung.class);
        startActivity(Reg);
    }

    // Durch Tastendruck die Anzeige der App verändern
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event){

        switch (keyCode){
            case KeyEvent.KEYCODE_1:
                System.out.println("11111");
                a = 1;
                postboxAnzeige();
                return true;
            case KeyEvent.KEYCODE_2:
                System.out.println("22222");
                a = 2 ;
                postboxAnzeige();
                return true;

        }
        return super.onKeyDown(keyCode, event);
    }

    //Die Steuerung der Anzeige
    public void postboxAnzeige (){
                if (a == 1){
                    imgVollSma.setVisibility(View.VISIBLE);
                    imgLeerSma.setVisibility(View.INVISIBLE);
                    TVAnzeigeSma.setText("Sie haben Post!");
                    notification();
                }
                else {
                    imgVollSma.setVisibility(View.INVISIBLE);
                    imgLeerSma.setVisibility(View.VISIBLE);
                    TVAnzeigeSma.setText("Der Briefkasten ist leer!");
                }
    }

    //Senden der Benachrichtung an das Handy -> Push up Nachrichten
    public void notification(){
        if (CBAnzeigeAktivierenSma.isChecked()){
        NotificationCompat.Builder notificationBuilder = (NotificationCompat.Builder) new NotificationCompat.Builder(this)
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setLargeIcon(BitmapFactory.decodeResource(getResources(), R.drawable.ic_launcher_foreground))
                .setContentTitle("Nachricht von SmartPostbox")
                .setContentText("Sie haben Post!");
        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.notify(1, notificationBuilder.build());
    }else{}
    }

    //Daten vom Server empfangen/Daten anfragen
    public void sendToServer() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    URL scriptur1 = new URL(url_particle);
                    HttpURLConnection connection = (HttpURLConnection) scriptur1.openConnection();
                    connection.setDoInput(true); //evtl Input

                    InputStream datenHolen = connection.getInputStream();
                    final String antwort = getTextFromCloud(datenHolen);

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            TVSmart.setText(antwort);
                        }
                    });
                    datenHolen.close();
                    connection.disconnect();

                    System.out.println("URL funktioniert yuuuhhhuuu");
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                    System.out.println("URL funktioniert nicht");
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

        }).start();
    }

   //Internet Verbindung überprüfen
    public boolean internetAvailable(){
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        return networkInfo != null && networkInfo.isConnectedOrConnecting();
    }

   //Textdatein von der Cloud erhalten
    public String getTextFromCloud(InputStream is){
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        StringBuilder stringBuilder = new StringBuilder();
        String aktuelleZeile;

        try {
            while ((aktuelleZeile = reader.readLine()) != null){
                stringBuilder.append(aktuelleZeile);
                stringBuilder.append("\n");

            }
        }catch (IOException e){
            e.printStackTrace();
        }

        return stringBuilder.toString().trim();
    }
}
