package com.example.smartpostbox;

import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class Anmeldung extends AppCompatActivity {

    private EditText TextBenutzernameAnm;
    private EditText TextPasswortAnm;
    private TextView textViewAusgabe;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_anmeldung);

        TextBenutzernameAnm = (EditText) findViewById(R.id.TextBenutzernameAnm);
        TextPasswortAnm = (EditText) findViewById(R.id.TextPasswortReg);
        textViewAusgabe = (TextView) findViewById(R.id.textViewAusgabe);

        //Zurück Button
        Button btnZuruckAnm = (Button) findViewById(R.id.btnZuruckAnm);
        btnZuruckAnm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMainAn();
            }
        });

        //Weiter Button -> SmartMain
        Button btnWeiterAnm = (Button) findViewById(R.id.btnWeiterAnm);
        btnWeiterAnm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            speichern();


            }
        });
    }

    //Anmeldung Daten aufnehmen und Weiter auf SmartpostboxMain gehen
    private void speichern(){
        if(TextPasswortAnm.getText().toString().equals("12")){
            //Toast.makeText(getApplicationContext(), "Anmeldung erfolgreich", Toast.LENGTH_LONG);
            Intent go = new Intent(Anmeldung.this, SmartpostboxMain.class);
            startActivity(go);
        }else{
            System.out.println("ja");
        }
    }

    public void openMainAn(){
        Intent MainAnmMai = new Intent(this, MainActivity.class);
        startActivity(MainAnmMai);
    }

}
